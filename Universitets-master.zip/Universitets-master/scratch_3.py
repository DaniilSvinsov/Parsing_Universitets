import json
traffic = json.load(open('Universitets.json', encoding='utf-8-sig'))
names = ['Название', ]